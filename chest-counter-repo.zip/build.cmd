@echo off
setlocal
cd /d "%~dp0"
rem Builds ChestCounter.exe with the C# compiler that ships with Windows (nothing to install),
rem then zips it up as ChestCounter-v1.0.zip so you can share it.
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
"%CSC%" /nologo /target:winexe /optimize+ /out:ChestCounter.exe /win32icon:chest.ico /win32manifest:ChestCounter.manifest /resource:chest.png,chest.png /reference:System.Windows.Forms.dll /reference:System.Drawing.dll ChestCounter.cs
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo Built ChestCounter.exe
powershell -NoProfile -Command "Compress-Archive -Path 'ChestCounter.exe','README.txt' -DestinationPath 'ChestCounter-v1.0.zip' -Force"
if exist ChestCounter-v1.0.zip echo Made ChestCounter-v1.0.zip - this is the file to share.
pause
